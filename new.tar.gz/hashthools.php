<?php
function vaildate($algo, $source_hash, $destination_data){
	
	$destination_hash = hash($algo , $destination_data, false);
	
	if (!strcmp($source_hash, $destination_hash)){
		//when same
		
		return true;
		
	}
	
	return false;
	
}


function genhash($algo, $source_data){
	
	return hash($algo, $source_data, flase);
}


?>