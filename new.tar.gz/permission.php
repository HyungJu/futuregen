﻿<?php
$permission_folder = './special';

function getPermission($userid){
	$fpsoo = fopen('./special/soo.txt','r');
	$soo_data = fread($fpsoo,filesize('./special/soo.txt'));
	fclose($fpadmin);
	$fpadmin = fopen('./special/admin.txt','r');
	$admin_data = fread($fpadmin,filesize('./special/admin.txt'));
	fclose($fpadmin);
	$admin_arr = split('/',$admin_data);
	
	for ($i=0;$i<count($admin_arr);$i++){
		if ($userid == $admin_arr[$i])
			return 'admin';
	}
	if (preg_match($soo_data, $userid)) 
		return 'yongma';

}

function givePermission($userid){
	$fpadmin = fopen('./special/admin.txt','r');
	$admin_data = fread($fpadmin,filesize('./special/admin.txt'));
	fclose($fpadmin);
	$fpadmin = fopen('./special/admin.txt','w');
	fwrite($fpadmin, $admin_data.'/'.$userid);
	
}

givePermission('yongma_10215');

?>