<?php
//Hyungju SUNG

session_start();
session_destroy();
?>

<meta http-equiv='refresh' content='0;url=./index.php'>