﻿<?php
	
	require('permission.php'); //hash library
	session_start();

	$id=$_SESSION['userid'];
	if (getPermission($id) != true)
	echo "<meta http-equiv='refresh' content='0;url=./index.php'>";
	else
	echo"<meta http-equiv='refresh' content='0;url=./soo.php'>";

	
	

	?>
	
  