﻿<?php
//Hyungju SUNG

require('hashtools.php'); //hash library
$fpsoo = fopen('./special/soo.txt','r');
$soo_data = fread($fpsoo,filesize('./special/soo.txt'));
$soo = str_replace('/i','',$soo_data);
$soo = str_replace('/','',$soo);

fclose($fpadmin);
$fg_id = $_POST['userid']; 
$fg_id2 = $fg_id;
$fg_pw = $_POST['password'];
$fg_mode = $_POST['mode'];
$fg_pw_hash = genhash('sha256',$fg_pw); //encrypt password with sha256
if ($fg_mode)
	$fg_id = $soo.$fg_id;
echo "디버그 <br> 사용자 비번:$fg_pw<br>";
echo "사용자 아이디 :$fg_id<br>";
echo "사용자 비번 hash :$fg_pw_hash<br>";
echo "가입 모드 :$fg_mode<br>";
echo "수행 prefix :$soo<br>";
mkdir('./user/'.$fg_id, 0777);
$loginfile = fopen('./user/'.$fg_id.'/password.txt', 'w'); //write password file
fwrite ($loginfile, $fg_pw_hash);
fclose($loginfile);

?>

