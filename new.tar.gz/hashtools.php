<?php
function vaildate($algo, $source_hash, $destination_data){
	
	$destination_hash = hash($algo , $destination_data, false);
	
	
	
	return $destination_hash;
	if (!strcmp ($source_hash ,$destination_hash)){
		//when same
		
		return 10;
		
	}

	
	
}
function genhash($algo, $source_data){
	
	return hash($algo, $source_data, false);
}




?>