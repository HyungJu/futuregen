
<!DOCTYPE html>
<html>
<head>
<title> FUTUREGEN </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>

<body>

 <?
 
		$orgdap = $_GET['orgdap'];
		$dap = $_GET['dap'];
		$sta = $_GET['stage'];
		$mode = $_GET['mode'];
$userid = $_GET['userid'];
echo $sta;
	//$sta = substr($sta,-8); //음? 스테이지를 자르네요.. 제가 만들었어도 모르겠네요 ㅋㅋㅋ
	if($dap == $orgdap){
		
		echo "<script>window.open(\"./learn.php?stage=".$sta."&prog=ok&userid=$userid&mode=$mode\")</script>";
	}
	
	else {
		
		echo "<script>window.open(\"./learn.php?stage=".$sta."&prog=&userid=$userid&mode=$mode\")</script>";
	}
	echo "<script>window.close()</script>";
 ?>
   

</html>
