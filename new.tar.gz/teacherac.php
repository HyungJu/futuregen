<?php


$title = $_POST['title'];
$comment = $_POST['comment'];
$score = $_POST['score'];
$teacher = $_POST['teacher'];
$random = $_POST['random'];
$dir = 'yongma/'.$random;
mkdir($dir,0777);
$fp = fopen($dir.'/name.txt','w');
fwrite($fp, $title);
fclose($fp);

$fp = fopen($dir.'/question.txt','w');
fwrite($fp, $comment);
fclose($fp);

$fp = fopen($dir.'/score.txt','w');
fwrite($fp, $score);
fclose($fp);

$fp = fopen($dir.'/teacher.txt','w');
fwrite($fp, $teacher);
fclose($fp);

$fp = fopen('yongma/problem.txt','r+');
$data = fread($fp, filesize('yongma/problem.txt'));


fwrite($fp, '/'.$random);

fclose($fp);
echo"<script>window.history.go(-2);</script>";
?>
