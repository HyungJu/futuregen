﻿<?php
//Hyungju SUNG
session_start();
require('hashtools.php'); //hash library
$fg_id = $_POST['userid']; 
$fg_pw = $_POST['password'];
echo '<h3>디버그.</h3> <br> 인식된 유저id: '.$fg_id.'<br>';
echo '인식된 유저pw: '.$fg_pw.'<br>';
$fpsoo = fopen('./special/soo.txt','r');
$soo_data = fread($fpsoo,filesize('./special/soo.txt'));
$soo = str_replace('/i','',$soo_data);
$soo = str_replace('/','',$soo);

$loginfile = fopen('./user/'.$fg_id.'/password.txt', 'r'); //read password file

$hash = fread($loginfile,filesize('./user/'.$fg_id.'/password.txt'));
echo '오리지날 hash 값: '.$hash.'<br>';
echo '오리지날 pw 경로: '.'./user/'.$fg_id.'/password.txt'.'<br>';
echo '수행 prefix: '.$soo.'<br>';
echo 'genhash 함수 테스트: 입력 데이터: '.$fg_pw.' 출력 데이터:'.genhash('sha256',$fg_pw).'<br>';
$var = vaildate('sha256', $hash, $fg_pw);
fclose($loginfile);
echo 'hashtools.php 에서 처리한 hash 값: '.$var;

if($var == true){

	$_SESSION['userid'] = $fg_id;
	$_SESSION['hash'] = $hash;	
	echo "<br>비밀번호 인증 성공. 세션 ID: ".session_id();
}
	
?>

