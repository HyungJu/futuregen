﻿
<!DOCTYPE html>
<html>
<head>
<title> FUTUREGEN </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/css/bootstrap.min.css" integrity="sha384-MIwDKRSSImVFAZCVLtU0LMDdON6KVCrZHyVQQj6e8wIEJkW4tvwqXrbMIya1vriY" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/js/bootstrap.min.js" integrity="sha384-ux8v3A6CPtOTqOzMKiuo3d/DomGaaClxFYdCu2HPMBEkf6x2xiDyJ7gkXU0MWwaD" crossorigin="anonymous"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>

<body>
<nav class="navbar navbar-fixed-top navbar-dark bg-primary">
  <!-- Navbar content -->
  <div class="nav navbar-nav">
    <a class="nav-item nav-link active" href="./">FutureGen <span class="sr-only">(current)</span></a>
    <a href="./logout.php"class="nav-item nav-link pull-xs-right ">
    <?php
	session_start();
    $id=$_SESSION['userid'];
	if($id)
	echo"$id 님 환영합니다! (클릭하여 로그아웃)";
	?>
	
  </a>
  

  </div>
</nav>
<br>
<br>
<br>
<br>
<div class="container">
<div class="card card-block">
  <h4 class="card-title">가입</h4>
  <p class="card-text">용마중학교에 재학중인 학생분들께서는 <a href="yongma.php">이곳을 이용해주세요.</a></p>
  <form action="join.php" method="post">

  
    <input class="form-control" name="userid" type="userid" placeholder="아이디">
	<input class="form-control" name="password" type="password" type="password" placeholder="패스워드">
    <button class="btn btn-outline-success" type="submit">로그인</button>
  </form>

  </div>
  </div>


</html>
