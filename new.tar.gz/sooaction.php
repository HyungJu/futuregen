<?php
$content = $_POST['content'];
$problem = $_POST['question'];
session_start();
$id = $_SESSION['userid'];

$fp = fopen('./yongma/'.$problem.'/'.$id.'.txt','w');
fwrite($fp, $content);
echo"<script>window.history.go(-2);</script>";
?>
