﻿
<!DOCTYPE html>
<html>
<head>
<title> FUTUREGEN </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/css/bootstrap.min.css" integrity="sha384-MIwDKRSSImVFAZCVLtU0LMDdON6KVCrZHyVQQj6e8wIEJkW4tvwqXrbMIya1vriY" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/js/bootstrap.min.js" integrity="sha384-ux8v3A6CPtOTqOzMKiuo3d/DomGaaClxFYdCu2HPMBEkf6x2xiDyJ7gkXU0MWwaD" crossorigin="anonymous"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>

<body>
<nav class="navbar navbar-fixed-top navbar-dark bg-primary">
  <!-- Navbar content -->
  <div class="nav navbar-nav">
    <a class="nav-item nav-link active" href="./">FutureGen <span class="sr-only">(current)</span></a>
  </div>
</nav>
<br>
<div class = "container">
 <?
 // 문제풀이.
 session_start();
 
 
 
 
		ini_set(display_errors,0);
		$stage = $_GET['stage'];
		$prog = $_GET['prog'];
		$userid = $_SESSION['userid'];
		$mode = $_GET['mode'];
		if ($mode == 'chal'){
		$moonfp = fopen("cha/moon.txt","r");
		$moon = fread($moonfp, filesize("cha/moon.txt"));
		$ansfp = fopen("cha/ans.txt","r");
		$ans = fread($ansfp, filesize("cha/ans.txt"));
		$haefp = fopen("cha/hae.txt","r");
		$hae = fread($haefp, filesize("cha/hae.txt"));
			
		}
		
		else if ($mode == "soon"){
			
		$stagefile1 = fopen("soon/".$stage."1.".txt,"r");
		$stagefile2 /* 2번이네요.*/ = fopen("soon/".$stage."hae.".txt,"r"); //해설 아이 이상해
		$stagefile3 = fopen("soon/".$stage."ans.".txt,"r"); //답
		}
		else{
		$stagefile1 = fopen("problem/".$stage."/moon.txt","r");
if($userid != "noid")
		$fp3 = fopen("user/$userid/"."no.txt",'rw');
		$stagefile3 = fopen("problem/".$stage."/ans.txt","r");
		$stagefile4 = fopen("problem/".$stage."/hae.txt","r");
		
		}
		
		
				if ($mode == 'soon'){
			$s1  = fgets($stagefile1);
			$s1 = str_replace("\\","",$s1);
							$s4  = fgets($stagefile2);
			$s4 = str_replace("\\","",$s4); //쓰레기 ㄷ  //아 ㅋㅋㅋ 모드를 잘못했네요 ㅋㅋㅋㅋㅋㅋㅋ

$s3  = fgets($stagefile3);			}


	else	if ($mode == 'chal'){
			$s1  = fgets($stagefile1);
			$s1 = str_replace("\\","",$s1);
$s3  = fgets($stagefile3);			} //오늘도 느끼는 쓰레기 코드

else{ //예. 여기가 일반 모드 입니다.ㅇ
		$s1  = fgets($stagefile1);
$s1 = str_replace("\\","",$s1);
						$s4  = fgets($stagefile4);
						$s3  = fgets($stagefile3);
						$s4 = str_replace("\\","",$s4); //네 끝!!
}
				if($prog == "ok"){
			
			if($mode != "chal"){
				$fop = fopen('./user/'.$userid.'/'.$stage.'.txt','w');
				fwrite($fop,'true');
				
					
			
				
			echo "<br><br><div class=\"alert alert-success\">
  <strong>성공!</strong> 맞았습니다! 이제 설명을 들으러 갈까요?.
 

</div>";
if($mode == "soon"){
//$hell = fopen("user/$userid"."soon.txt","w");
$hell = fopen("user/$userid"."soon.txt","w");

	fwrite($hell,$stage+1);
	
}
if($userid != "id=\"usr2\"")

echo "해설: <div style=\"background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;\"><pre style=\"margin: 0; line-height: 125%\"><span style=\"color: #008800; font-weight: bold\">".$s4."</span></pre>";
			}
		if($mode == 'chal'){
				echo "<br><br><div class=\"alert alert-success\">
  <strong>와우!</strong> 맞았습니다! 새로운 챌린지를 내세요!
  
</div>";
$fpfp = fopen("chal/chalable.txt","w");
		 fwrite($fpfp,$userid);

echo "<button onClick=\"window.open('cdap.php?userid=$userid');\" class='btn btn-success'>여기를 눌러서 문제내기</button>";
				}
		
		}
		
				if($prog == "notyet"){
			
			echo "<br><br><div class=\"alert alert-success\">
  <strong>와우!</strong> 첫도전이군요! 문제란에 있는 내용을 구해보세요!.
</div>";

		}
	else 	if ($prog == "re"){
				echo "<br><br><div class=\"alert alert-success\">
  <strong>하낫둘!</strong> 틀린문제는 천천히!
</div>";
		}
	 else if($prog != "ok" ){
			
			if($prog != "notyet" ){
			



	if ($mode != "chal"){
		
		if ($mode != "soon"){
if($userid != "noid" || $userid != ''){
	
	$fpfp = fopen('./user/'.$userid.'/'.$stage.'.txt','w');
	fwrite ($fpfp,'false');

}




		}
	}
if($mode == 'chal'){
				echo "<br><br><div class=\"alert alert-danger\">
  <strong>이런!</strong> 틀렸습니다! 다시 시도해서 1인자가 되세요!
  
</div>";

				}
				
				
				else if ($mode == "soon"){
					
						echo "<br><br><div class=\"alert alert-danger\">
  <strong>어익후!</strong> 틀렸습니다! 이문제를 풀어야 다음으로 진행가능합니다!.
  
</div>";
				}
				else{
			echo "<br><br><div class=\"alert alert-danger\">
  <strong>어익후!</strong> 틀렸습니다! 다시 풀 문제 목록에 저장했습니다!.
  
</div>";

				}
		}



		}
		
			if ($prog!= "ok"){
				if($prog!="np"){
		echo "문제: <div style=\"background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;\"><pre style=\"margin: 0; line-height: 125%\"><span style=\"color: #008800; font-weight: bold\">".$s1."</span></div>";
		
		if ($stage == "chal" ||$mode == "soon"  ){
				echo "<br> <br><form action=\"chk.php\" method=\"get\">
			

 <label for=\"usr\">답을 입력하세요:</label>
  <input type=\"text\" name=\"dap\" class=\"form-control\" id=\"usr\">
  <input type=\"hidden\" name=\"orgdap\" class=\"form-control\" value=".$s3." id=\"us3r\">
  <input type=\"hidden\" name=\"stage\"  class=\"form-control\" value=$stage id=\"usr1\">
   <input type=\"hidden\" name=\"userid\" class=\"form-control\" value=$userid id=\"usr2\">
    <input type=\"hidden\" name=\"mode\" class=\"form-control\" value=$mode id=\"usr5\">
 </form>
";
			
		}
		
		else {
		echo "<br> <br><form action=\"chk.php\" method=\"get\">
			

 <label for=\"usr\">답을 입력하세요:</label>
  <input type=\"text\" name=\"dap\" class=\"form-control\" id=\"usr\">
  <input type=\"hidden\" name=\"orgdap\" class=\"form-control\" value=".$s3." id=\"us3r\">
  <input type=\"hidden\" name=\"stage\"  class=\"form-control\" value=$stage id=\"usr1\">
   <input type=\"hidden\" name=\"userid\" class=\"form-control\" value=$userid id=\"usr2\">
 </form>
";
		}	}
				if($prog == "np")
				echo "틀린 문제를 진행하십시오!";
			
	
			}
 ?>

</div>
</div>
</html>
