<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.4/css/bootstrap.min.css" integrity="2hfp1SzUoho7/TsGGGDaFdsuuDL0LX2hnUp6VkX3CUQ2K4K+xjboZdsXyp4oUHZj" crossorigin="anonymous">
  </head>
 
<body>
<div class="container">
<?php
$problem = $_GET['question'];

$d = dir("yongma/$problem");
while (false !== ($entry = $d->read())) {
  $yongmatxt = strstr($entry,'yongma');
  $writer = str_replace('.txt','',$yongmatxt);
  $fp = fopen('yongma/'.$problem.'/'.$yongmatxt,'r');
  $res = fread($fp, filesize('yongma/'.$problem.'/'.$yongmatxt));
  $res = nl2br($res);

  if($yongmatxt){
	    echo '<div class="card card-block">
  <h4 class="card-title">'.$writer.'</h4>
  <p class="card-text">'.$res.'</p>

</div>';
}
  }

$d->close();
?>
</div>
</body>
</html>